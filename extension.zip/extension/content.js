const EMOTIONS = ['CALM', 'NORMAL', 'EXCITED', 'STRESSED'];
const EMOTION_CLASS = ['', 'normal', 'excited', 'stressed'];
const MEMBERS = { j:'JIN', s:'SUGA', r:'RM', jh:'J-HOPE', jm:'JIMIN', v:'V', jk:'JUNGKOOK' };

let widget = null;
let member = 'jk';
let emotion = 0;
let isDragging = false;
let dragOffset = { x: 0, y: 0 };
let currentPanel = null;

async function init() {
  const data = await chrome.storage.local.get(['selectedMember', 'emotion', 'visible', 'position']);
  member = data.selectedMember || 'jk';
  emotion = data.emotion || 0;
  
  createWidget();
  
  if (data.visible === false) {
    widget.classList.add('hidden');
  }
  
  if (data.position) {
    widget.style.right = 'auto';
    widget.style.bottom = 'auto';
    widget.style.left = data.position.x + 'px';
    widget.style.top = data.position.y + 'px';
  }
  
  updateWidget();
}

function createWidget() {
  widget = document.createElement('div');
  widget.id = 'withfave-widget';
  widget.style.right = '20px';
  widget.style.bottom = '20px';
  
  widget.innerHTML = `
    <div class="wf-container">
      <div class="wf-nav">
        <button class="wf-btn-settings" title="Settings">⚙️</button>
        <button class="wf-btn-info" title="Info">ℹ️</button>
      </div>
      <button class="wf-close" title="Hide">×</button>
      <img class="wf-char" src="${chrome.runtime.getURL('images/jk0.png')}" draggable="false">
      <span class="wf-emotion">CALM</span>
    </div>
    <div class="wf-panel wf-settings-panel">
      <div class="wf-grid"></div>
    </div>
    <div class="wf-panel wf-info-panel">
      <div class="wf-info">
        <p>Tabs: <b id="wf-tabs">0</b></p>
        <p>😌≤5 🙂≤15 😄≤30 😤30+</p>
        <a href="https://ko-fi.com/H2H61W7DT8" target="_blank">☕ Support</a>
      </div>
    </div>
  `;
  
  document.body.appendChild(widget);
  
  setupDrag();
  setupEvents();
  renderGrid();
}

function setupDrag() {
  const container = widget.querySelector('.wf-container');
  
  container.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true;
    const rect = widget.getBoundingClientRect();
    dragOffset.x = e.clientX - rect.left;
    dragOffset.y = e.clientY - rect.top;
    widget.style.right = 'auto';
    widget.style.bottom = 'auto';
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const x = e.clientX - dragOffset.x;
    const y = e.clientY - dragOffset.y;
    widget.style.left = x + 'px';
    widget.style.top = y + 'px';
  });
  
  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      const rect = widget.getBoundingClientRect();
      chrome.storage.local.set({ position: { x: rect.left, y: rect.top } });
    }
  });
}

function setupEvents() {
  widget.querySelector('.wf-close').addEventListener('click', () => {
    widget.classList.add('hidden');
    chrome.storage.local.set({ visible: false });
  });
  
  widget.querySelector('.wf-char').addEventListener('click', () => {
    emotion = (emotion + 1) % 4;
    chrome.storage.local.set({ emotion });
    updateWidget();
  });
  
  widget.querySelector('.wf-btn-settings').addEventListener('click', (e) => {
    e.stopPropagation();
    togglePanel('settings');
  });
  
  widget.querySelector('.wf-btn-info').addEventListener('click', (e) => {
    e.stopPropagation();
    togglePanel('info');
  });
  
  document.addEventListener('click', (e) => {
    if (!widget.contains(e.target)) {
      closeAllPanels();
    }
  });
}

function togglePanel(type) {
  const panel = widget.querySelector(`.wf-${type}-panel`);
  const isOpen = panel.classList.contains('show');
  
  closeAllPanels();
  
  if (!isOpen) {
    panel.classList.add('show');
    if (type === 'info') updateTabCount();
  }
}

function closeAllPanels() {
  widget.querySelectorAll('.wf-panel').forEach(p => p.classList.remove('show'));
}

async function updateTabCount() {
  const tabs = await chrome.tabs.query({});
  const el = widget.querySelector('#wf-tabs');
  if (el) el.textContent = tabs.length;
}

function renderGrid() {
  const grid = widget.querySelector('.wf-grid');
  grid.innerHTML = '';
  
  Object.keys(MEMBERS).forEach(k => {
    const card = document.createElement('div');
    card.className = `wf-card${k === member ? ' sel' : ''}`;
    card.innerHTML = `<img src="${chrome.runtime.getURL(`images/${k}1.png`)}">`;
    card.addEventListener('click', () => selectMember(k));
    grid.appendChild(card);
  });
}

function selectMember(k) {
  member = k;
  chrome.storage.local.set({ selectedMember: k });
  renderGrid();
  updateWidget();
}

function updateWidget() {
  const img = widget.querySelector('.wf-char');
  img.src = chrome.runtime.getURL(`images/${member}${emotion}.png`);
  
  const label = widget.querySelector('.wf-emotion');
  label.textContent = EMOTIONS[emotion];
  label.className = 'wf-emotion ' + EMOTION_CLASS[emotion];
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'toggle') {
    widget.classList.toggle('hidden');
  }
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.emotion) {
    emotion = changes.emotion.newValue;
    updateWidget();
  }
});

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
